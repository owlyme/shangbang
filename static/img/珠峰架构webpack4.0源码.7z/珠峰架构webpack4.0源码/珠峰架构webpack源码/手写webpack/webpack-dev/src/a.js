let b = require('./base/b.js')
module.exports = 'a' + b;