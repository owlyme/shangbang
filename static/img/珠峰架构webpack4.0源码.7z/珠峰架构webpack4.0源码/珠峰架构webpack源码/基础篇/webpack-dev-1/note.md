## 1.webpack安装
- 安装本地的webpack 

- webpack webpack-cli -D

  - 加一个-D表示开发依赖 上线的时候不需要这两个包

  1.初始化 init -y

```javascript
yarn add webpack wabpack-cli -D
```
## 2.webpack可以进行0配置

不需配置也可以使用

- 打包工具 -> 输出后的结果 (js模块)
  - 打包目录 src文件夹下的index.js
- 打包 (支持我们的js的模块化)

## 手动配置webpack
- 默认配置文件的名字 webpack.config.js