let str = require('./a.js');
require('./index.less');
console.log(str);