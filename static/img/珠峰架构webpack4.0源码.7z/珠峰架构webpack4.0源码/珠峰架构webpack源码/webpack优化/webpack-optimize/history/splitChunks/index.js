import './a';
import './b';
console.log('index.js');

import $ from 'jquery'
console.log($);