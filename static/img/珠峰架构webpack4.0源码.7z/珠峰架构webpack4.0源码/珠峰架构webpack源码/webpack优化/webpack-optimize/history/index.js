import React from 'react';
import {render} from 'react-dom';
render(<h1>jsx1</h1>,window.root)

// import jquery from 'jquery';
// import moment from 'moment';
// // 设置语言

// // 手动引入所需要的语言
// import 'moment/locale/zh-cn'

// moment.locale('zh-cn');


// let r = moment().endOf('day').fromNow();   
// console.log(r);